# Citation Positioning Notes

## Short Method Tagline

DASC is a drift-aware conformal calibration framework for streaming data that combines spectral relevance weighting, transport drift monitoring, adaptive calibration, and effective-sample-size diagnostics.

## Citable Concepts

- **DASC diagnostic triangle:** local coverage error, transport drift, and effective sample size.
- **DASC reliability index:** a single monitoring score that decreases when drift rises, effective sample size falls, or local coverage moves away from target.
- **Drift-gated spectral conformal calibration:** a weighted conformal rule that borrows from recurring regimes but gates stale calibration history under drift.
- **Calibration-layer benchmarking:** comparison under a shared simple forecaster so differences are attributed mainly to the conformal mechanism.

## Suggested Reuse Sentence

Researchers can reuse DASC as a diagnostic calibration layer around any streaming forecaster by replacing the spectral feature map with a domain-specific representation and monitoring the same drift, coverage, and effective-sample-size quantities.

## Why The Paper Is Citation-Friendly

- It names a concrete problem: conformal calibration under structured non-exchangeability with drift.
- It gives a reusable framework, not only a single dataset result.
- It includes theory, ablations, stress tests, and real-data evidence.
- It provides a one-command experiment regeneration script.
- It reports a hard-case finance example instead of hiding a limitation.
