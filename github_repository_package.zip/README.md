# Drift-Aware Spectral Conformal Prediction

This repository contains the manuscript source, code, figures, and reproducibility workflow for:

**Drift-Aware Spectral Conformal Prediction for Non-Exchangeable Streaming Data**

The paper develops drift-aware spectral conformal prediction (DASC), a conformal uncertainty method for streaming data with recurring structure, changing seasonal frequencies, abrupt shifts, and gradual drift.

## What Is In This Repository

- `main.tex`: LaTeX manuscript source.
- `references.bib`: bibliography.
- `figures/`: manuscript figures.
- `scripts/dasc.py`: reusable DASC implementation.
- `scripts/run_first_simulation.py`: synthetic recurring-regime experiment.
- `scripts/run_stress_tests.py`: five-regime robustness study.
- `scripts/run_external_mapie_benchmarks.py`: external EnbPI and AgACI-style comparison.
- `scripts/run_ablation.py`: component ablation study.
- `scripts/tune_dasc.py`: DASC tuning grid.
- `scripts/download_real_data.py`: UCI household power download script.
- `scripts/download_weather_data.py`: Open-Meteo Dallas weather download script.
- `scripts/download_finance_data.py`: FRED S&P 500 download script.
- `scripts/run_real_power_experiment.py`: electricity-stream experiment.
- `scripts/run_real_weather_experiment.py`: weather-stream experiment.
- `scripts/run_real_finance_experiment.py`: financial-volatility experiment.
- `scripts/make_cross_domain_summary.py`: cross-domain summary table.
- `scripts/make_diagnostic_figure.py`: diagnostic figure generator.
- `scripts/make_result_figures.py`: manuscript figure generator.
- `scripts/run_all_experiments.py`: one-command empirical workflow.
- `results/`: compact summary outputs used by the manuscript.

Large downloaded datasets and large intermediate result files are intentionally excluded from version control. They can be regenerated from the scripts.

## Installation

Create a Python environment and install the dependencies:

```bash
pip install -r requirements.txt
```

The experiments use public Python packages including NumPy, pandas, scikit-learn, matplotlib, Pillow, and MAPIE.

## Reproducing The Experiments

From the repository root, run:

```bash
python scripts/run_all_experiments.py
```

This regenerates the synthetic studies, stress tests, MAPIE comparisons, real-data experiments, summary tables, and manuscript figures.

The real-data scripts download public data from:

- UCI Machine Learning Repository: household electric power consumption.
- Open-Meteo historical archive: Dallas hourly temperature.
- Federal Reserve Economic Data: S&P 500 daily series.

## Manuscript

To compile the manuscript locally:

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

The current arXiv source-only package is:

`arxiv_submission_source_only.zip`

## Citation

If this work is useful, please cite the manuscript using the metadata in `CITATION.cff`.

## License

Code is released under the MIT License. The manuscript remains copyright of the authors.
